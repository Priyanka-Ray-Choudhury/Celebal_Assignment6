# Retrieving data. Wait a few seconds and try to cut or copy again.

Reference :- https://www.electronicshub.org/how-to-fix-retrieving-data-wait-a-few-seconds-and-try-to-cut-or-copy-again/

⚠ Probably the question that was being read from excel file could not be read and hence this error message was saved in the website and display instead of actual question.

The question heading can be verified from above reference link. This is something not related to azure and probably a backend issue where task data was not copied to database successfully and instead dummy text was stored.